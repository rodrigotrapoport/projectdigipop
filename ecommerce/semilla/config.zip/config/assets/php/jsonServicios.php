<?php
$jsonServicios = 
'{
	"servicios" : {
		"servicios1" : {
			"id"          : "1",
			"nombre"      : "Plomeria profesional",
			"descripcion" : "Trabajo en casas, &quot;edificios&quot; y muchas cosas raras",
			"condi"       : "Entrevista gratuita, se emite un presupuesto donde debe ser pago 50% al comenzar, y 50% al finalizar.",
			"precioA"     : "199",
			"precioB"     : "99",
			"moneda"      : "USD",
			"mostrarPrecio" : "si",
			"visibilidad" : "si",
			"testimonio"  : { 
				"cliente1" : { 
							"cliente"       : "Alberto Perez q1",
							"posicion"      : "Dueño de tienda",
							"comentario"    : "Excelente servicio"
							},
				"cliente2" : { 
							"cliente"       : "Julieta Gomez q1",
							"posicion"      : "Dueño de tienda",
							"comentario"    : "Muy buen trato, excelente trato"
							}
						},
			"equipo"      : { 
				"miembro1" : {
							"miembro" : "Alberto Tete m1",
							"frase"   : "Plomero de 30 años", 
							"titulo"  : "plomero"
							}, 
				"miembro2" : {  
							"miembro" : "Julieta Toto m1",
							"frase"   : "Plomero de 30 años, con unos cuantos pirtulos", 
							"titulo"  : "plomera"
							}
						},
			"prioridad"   : "Alta",
			"slide"      : "Plomeros",
			"foto"        : "https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Fi.ytimg.com%2Fvi%2FDelnOgaCMvY%2Fmaxresdefault.jpg&f=1&nofb=1"
		},
		"servicios2" : {
			"id"          : "2",
			"nombre"      : "Plomeria profesional pppp",
			"descripcion" : "Trabajo en casas, &quot;edificios&quot; y muchas cosas raras",
			"condi"       : "Entrevista gratuita, se emite un presupuesto donde debe ser pago 50% al comenzar, y 50% al finalizar.",
			"precioA"     : "199",
			"precioB"     : "99",
			"moneda"      : "USD",
			"mostrarPrecio" : "no",
			"visibilidad" : "si",
			"testimonio"  : { 
				"cliente1" : { 
							"cliente"       : "Alberto Perez q2",
							"posicion"      : "Dueño de tienda",
							"comentario"    : "Excelente servicio"
							},
				"cliente2" : { 
							"cliente"       : "Julieta Gomez q2",
							"posicion"      : "Dueño de tienda",
							"comentario"    : "Muy buen trato, excelente trato"
							}
						},
			"equipo"      : { 
				"miembro1" : {
							"miembro" : "Alberto Tete m2",
							"frase"   : "Plomero de 30 años", 
							"titulo"  : "plomero"
							}, 
				"miembro4" : { 
							"miembro" : "Julieta Toto m2",
							"frase"   : "Plomero de 30 años, con unos cuantos pirtulos", 
							"titulo"  : "plomera"
							}
						},
			"prioridad"   : "Ninguna",
			"slide"      : "Plomeros home",
			"foto"        : "https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Fi.ytimg.com%2Fvi%2FDelnOgaCMvY%2Fmaxresdefault.jpg&f=1&nofb=1"
		}
	}
}';


		
?>